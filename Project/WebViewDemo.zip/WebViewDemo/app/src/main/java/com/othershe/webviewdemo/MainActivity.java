package com.othershe.webviewdemo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Stack;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.webview)
    WebView mWebView;

    @BindView(R.id.progress)
    ProgressBar mProgressBar;

    @BindView(R.id.title)
    TextView mTitle;

    @OnClick(R.id.back)
    void onClickBack() {
        popActivity();
    }

    private String url;

    private static Stack<MainActivity> mStack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        //用来模拟原生应用的页面跳转
        if (mStack == null) {
            mStack = new Stack<>();
        }

        mStack.push(this);

        url = getIntent().getStringExtra("url");

        initWebView();
    }

    private void initWebView() {
        WebSettings settings = mWebView.getSettings();
        settings.setJavaScriptEnabled(true);    //支持js
        settings.setUseWideViewPort(true);    //设置webview推荐使用的窗口，使html界面自适应屏幕
        settings.setLoadWithOverviewMode(true);     //缩放至屏幕的大小
        settings.setAllowFileAccess(true);      //设置可以访问文件 
//        settings.setDefaultZoom(WebSettings.ZoomDensity.MEDIUM);    //设置中等像素密度，medium=160dpi
        settings.setSupportZoom(true);    //设置支持缩放
        settings.setLoadsImagesAutomatically(true);    //设置自动加载图片
//        settings.setBlockNetworkImage(true);    //设置网页在加载的时候暂时不加载图片
//        settings.setAppCachePath("");   //设置缓存路径
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);   //设置缓存模式

        //在native中注入本地方法，供js调用
        mWebView.addJavascriptInterface(new JsOperation(), "client");


        if (url != null) {
            mWebView.loadUrl(url);
        } else {
            mWebView.loadUrl("http://www.jianshu.com/");
        }

//        mWebView.loadUrl("file:///android_asset/test.html");


        //WebChromeClient，辅助WebView处理Javascript的对话框，网站图标，网站title，加载进度等
        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                mTitle.setText(title);
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                if (newProgress == 100) {
                    mProgressBar.setVisibility(View.GONE);
                }
                mProgressBar.setProgress(newProgress);
            }

        });

        //WebViewClient，辅助WebView处理各种通知、请求事件的
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                intent.putExtra("url", url);
                startActivity(intent);

                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            }
        });

        //下载设置
        mWebView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype,
                                        long contentLength) {

            }
        });
    }

    //js调用java代码
    class JsOperation {
        @JavascriptInterface
        public void showMessage(String msg) {
            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
        }
    }

    private void javaCallJs(){
        //java调用js代码
        //click2是js方法名，1008611是传入的参数
        mWebView.loadUrl("javascript:click2" + "(" + 1008611 + ")");
    }

    private void goBack(){
        if (mWebView.canGoBack()){
            mWebView.goBack();
        }else{
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        popActivity();

//        javaCallJs();
    }


    private void popActivity() {
        if (mStack.size() > 0) {
            mStack.remove(this);
            this.finish();
        }
    }
}

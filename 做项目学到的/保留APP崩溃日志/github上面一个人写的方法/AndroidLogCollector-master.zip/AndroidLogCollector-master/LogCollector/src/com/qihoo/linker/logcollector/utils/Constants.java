package com.qihoo.linker.logcollector.utils;

/**
 * 
 * @author jiabin
 *
 */
public class Constants {

	public static boolean DEBUG = false;
}
